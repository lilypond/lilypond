val open = true
val inline = true
inline xval
val x = inline + 2
(using)
(usingSomething)
