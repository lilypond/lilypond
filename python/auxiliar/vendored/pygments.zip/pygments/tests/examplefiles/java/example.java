class _PostUnico$deClassá
{void fo$o() {}

  void PostUnicodeFunctioná() {
  láb$el:
    break láb$el;
  
  }
}

class áPreUnicode$Class
{
  public int $foo;
  public int á$foo;
  _PostUnico$deClassá áPreUnicodeFunction() { return null; }
}
